#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>
#include <sys/select.h>
#define SERVER_PORT 2028
#define MESSAGE_LENGTH 1024

int main()
{
    int client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket == -1)
    {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    struct sockaddr_in server_address = {
        .sin_family = AF_INET,
        .sin_port = htons(SERVER_PORT),
        .sin_addr.s_addr = inet_addr("127.0.0.1")};
    if (connect(client_socket, (struct sockaddr *)&server_address, sizeof(server_address)) == -1)
    {
        perror("connect");
        exit(EXIT_FAILURE);
    }

    printf("Connected to server.\n");

    fd_set readfds;
    FD_ZERO(&readfds);
    FD_SET(STDIN_FILENO, &readfds);
    FD_SET(client_socket, &readfds);

    while (1)
    {
        fd_set temp_fds = readfds;
        if (select(client_socket + 1, &temp_fds, NULL, NULL, NULL) == -1)
        {
            perror("select");
            exit(EXIT_FAILURE);
        }

        if (FD_ISSET(STDIN_FILENO, &temp_fds))
        {
            // Read input from user
            char message[MESSAGE_LENGTH];
            fgets(message, MESSAGE_LENGTH, stdin);
            message[strcspn(message, "\n")] = '\0';

            // Send message to server
            if (send(client_socket, message, strlen(message), 0) == -1)
            {
                perror("send");
                exit(EXIT_FAILURE);
            }
        }

        if (FD_ISSET(client_socket, &temp_fds))
        {
            // Read data from server
            char buffer[MESSAGE_LENGTH];
            int num_bytes = recv(client_socket, buffer, sizeof(buffer), 0);

            if (num_bytes == -1)
            {
                perror("recv");
                exit(EXIT_FAILURE);
            }
            else if (num_bytes == 0)
            {
                // Server disconnected
                printf("Server disconnected.\n");
                exit(EXIT_SUCCESS);
            }
            else
            {
                // Handle message from server
                buffer[num_bytes] = '\0';
                if (strncmp(buffer, "/activegroups", 13) == 0)
                {
                    char message[MESSAGE_LENGTH];
                    memset(message, '\0', strlen(message));
                    fgets(message, MESSAGE_LENGTH, stdin);
                    message[strcspn(message, "\n")] = '\0';
                    printf(buffer, "/broadcast %s", message);
                    if (recv(client_socket, buffer, strlen(buffer), 0) == -1)
                    {
                        perror("send");
                        exit(EXIT_FAILURE);
                    }
                    // printf("Broadcasted\n");
                }
                else if (strncmp(buffer, "/active", 7) == 0)
                {
                    // recv(client_socket, buffer, sizeof(buffer), 0);
                    printf("Online clients:\n%s", buffer + 8);
                }
                else if (strncmp(buffer, "/send", 5) == 0)
                {
                    int recipient_id = atoi(buffer + 5);
                    fprintf(stdout, "Enter message to send to client %d: ", recipient_id);

                    char message[MESSAGE_LENGTH];
                    fgets(message, MESSAGE_LENGTH, stdin);
                    message[strcspn(message, "\n")] = '\0';

                    // Send message to server
                    sprintf(buffer, "/send%d %s", recipient_id, message);
                    if (send(client_socket, buffer, strlen(buffer), 0) == -1)
                    {
                        perror("send");
                        exit(EXIT_FAILURE);
                    }
                }
                else if (strncmp(buffer, "/broadcast", 10) == 0)
                {
                    char message[MESSAGE_LENGTH];
                    memset(message, '\0', strlen(message));
                    fgets(message, MESSAGE_LENGTH, stdin);
                    message[strcspn(message, "\n")] = '\0';
                    // printf(buffer, "/broadcast %s",message);
                    if (send(client_socket, buffer, strlen(buffer), 0) == -1)
                    {
                        perror("send");
                        exit(EXIT_FAILURE);
                    }
                    printf("Broadcasted\n");
                }
                else if (strncmp("/quit", buffer, 5) == 0)
                {
                    char message[MESSAGE_LENGTH];
                    memset(message, '\0', strlen(message));
                    fgets(message, MESSAGE_LENGTH, stdin);
                    message[strcspn(message, "\n")] = '\0';
                    // printf(buffer, "/broadcast %s",message);
                    if (send(client_socket, buffer, strlen(buffer), 0) == -1)
                    {
                        perror("send");
                        exit(EXIT_FAILURE);
                    }
                    printf("Quitting\n");
                }

                else if (strncmp(buffer, "/makegroupbroadcast", 19) == 0)
                {
                    char message[1024];
                    //printf("enter input:");
                    memset(message, '\0', strlen(message));
                    fgets(message, MESSAGE_LENGTH, stdin);
                    message[strcspn(message, "\n")] = '\0';
                    if (recv(client_socket, buffer, strlen(buffer), 0) == -1)
                    {
                        perror("send");
                        exit(EXIT_FAILURE);
                    }
                }
                else if (strncmp(buffer, "/makegroup", 10) == 0)
                {
                    char message[MESSAGE_LENGTH];
                    memset(message, '\0', strlen(message));
                    fgets(message, MESSAGE_LENGTH, stdin);
                    message[strcspn(message, "\n")] = '\0';
                    printf(buffer, "/broadcast %s", message);
                    if (recv(client_socket, buffer, strlen(buffer), 0) == -1)
                    {
                        perror("send");
                        exit(EXIT_FAILURE);
                    }
                    // printf("Broadcasted\n");
                }
                else if (strncmp(buffer, "/makegroupreq", 13) == 0)
                {

                    char message[MESSAGE_LENGTH];
                    memset(message, '\0', strlen(message));
                    fgets(message, MESSAGE_LENGTH, stdin);
                    message[strcspn(message, "\n")] = '\0';
                    // printf(buffer, "/broadcast %s",message);
                    if (recv(client_socket, buffer, strlen(buffer), 0) == -1)
                    {
                        perror("send");
                        exit(EXIT_FAILURE);
                    }
                }
                else if (strncmp(buffer, "/joingroup", 10) == 0)
                {
                    char message[1024];
                    printf("enter input:");
                    memset(message, '\0', strlen(message));
                    fgets(message, MESSAGE_LENGTH, stdin);
                    message[strcspn(message, "\n")] = '\0';
                    if (recv(client_socket, buffer, strlen(buffer), 0) == -1)
                    {
                        perror("send");
                        exit(EXIT_FAILURE);
                    }
                }

                else if (strncmp(buffer, "/makeadmin", 10) == 0)
                {
                    char message[1024];
                    //printf("enter input:");
                    memset(message, '\0', strlen(message));
                    fgets(message, MESSAGE_LENGTH, stdin);
                    message[strcspn(message, "\n")] = '\0';
                    if (recv(client_socket, buffer, strlen(buffer), 0) == -1)
                    {
                        perror("send");
                        exit(EXIT_FAILURE);
                    }
                }
                else if (strncmp(buffer, "/addtogroup", 10) == 0)
                {
                    char message[1024];
                    //printf("enter input:");
                    memset(message, '\0', strlen(message));
                    fgets(message, MESSAGE_LENGTH, stdin);
                    message[strcspn(message, "\n")] = '\0';
                    if (recv(client_socket, buffer, strlen(buffer), 0) == -1)
                    {
                        perror("send");
                        exit(EXIT_FAILURE);
                    }
                }
                else if (strncmp(buffer, "/removefromgroup", 16) == 0)
                {
                    char message[1024];
                    //printf("enter input:");
                    memset(message, '\0', strlen(message));
                    fgets(message, MESSAGE_LENGTH, stdin);
                    message[strcspn(message, "\n")] = '\0';
                    if (recv(client_socket, buffer, strlen(buffer), 0) == -1)
                    {
                        perror("send");
                        exit(EXIT_FAILURE);
                    }
                }
                else if (strncmp(buffer, "/sendgroup", 10) == 0)
                {
                    char message[MESSAGE_LENGTH];
                    memset(message, '\0', strlen(message));
                    fgets(message, MESSAGE_LENGTH, stdin);
                    message[strcspn(message, "\n")] = '\0';
                    // printf(buffer, "/broadcast %s",message);
                    if (send(client_socket, buffer, strlen(buffer), 0) == -1)
                    {
                        perror("send");
                        exit(EXIT_FAILURE);
                    }
                    printf("Broadcasted\n");
                }
                else
                {
                    printf("%s\n", buffer);
                }
            }
        }
    }

    close(client_socket);
    return 0;
}
