#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <time.h>

#define MAX_CLIENTS 10
#define BUFFER_SIZE 1024
#define MAX_GROUP_MEMBERS 5

char *notadmin = "you are not admin\n";
int portno = 2028;
int k = 0;
int admincnt = 1;
struct group
{
    int gid;
    int cnt;
    int reply;
    int members[10];
    int admin[5];
    int is_broadcast;
};

struct group grps[10];

int grpno = 0;
struct clients
{
    int socket, id, group_id;
};
int numToks(char *str)
{
    int toks = 0;
    char *p = strtok(str, " ");
    while (p != NULL)
    {
        // printf("%s\n", p);
        p = strtok(NULL, " ");
        toks++;
    }
    return toks;
}

int is_admin(int cid, int gid)
{
    // printf("in is_admin cid:%d,gid :%d\n", cid, gid);
    int i = 0, j = 0;
    for (; i < grpno; i++)
    {
        if (grps[j].gid == gid)
        {
            for (; j < 5; j++)
            {
                if (grps[i].admin[j] == cid)
                {
                    // printf("cid==grps.cid\n");
                    return 1;
                }
            }
        }
    }
    return 0;
}
int find_sock(struct clients *clients, int n, int id)
{
    int i = 0;
    for (i = 0; i < n; i++)
    {
        if (clients[i].id == id)
            return clients[i].socket;
    }
    return 0;
}

int find_id(struct clients *clients, int n, int sock)
{ // for (int i=0; i < n; i++)
    //     {   printf("find _id cid %d sd %d\n",clients[i].id,clients[i].socket);}
    int i = 0;
    for (; i < n; i++)
    { // printf("find _id cid %d sd %d\n",clients[i].id,clients[i].socket);
        if (clients[i].socket == sock)
            return clients[i].id;
    }
    return 0;
}

void handle_makegroupbroadcast(int gid, int sd, struct clients *clients)
{
    // for(int p=0;p<10;p++)
    int l = 0;
    char *buf = "This group is now broadcast-only\n";
    // printf("k is :%d\n", k);
    int cid = find_id(clients, 10, sd);

    // printf("cid:%d sd : %d handlebroadcast\n", cid, sd);
    int u = is_admin(cid, gid);
    // printf("u is %d\n", u);
    if (u == 0)
    {
        send(sd, notadmin, strlen(notadmin), 0);
        return;
    }
    else
    {
        for (int i = 0; i < grpno; i++)
        {
            if (grps[i].gid == gid)
            {
                grps[i].is_broadcast = 1;
                for (int j = 0; j <= grps[i].cnt; j++)
                {
                    int p = find_sock(clients, grps[i].cnt, grps[i].members[j]);
                    printf("broadcast cnt: %d,mems:%d \n", grps[i].cnt, grps[i].members[j]);
                    send(p, buf, strlen(buf), 0);
                }
            }
        }
    }
}
void handle_sendgroup(int gid, char *msg, struct clients *clients, int sockd)
{
    int cid = find_id(clients, 10, sockd);
    if (is_admin(cid, gid) == 0)
    {
        send(sockd, notadmin, strlen(notadmin), 0);
        return;
    }
    char buf[256] = "This is broadcast msg:";
    strcat(buf, " ");
    strcat(buf, msg);
    for (int i = 0; i < grpno; i++)
    {
        if (grps[i].gid == gid && grps[i].is_broadcast == 1)
        {
            for (int j = 0; j < grps[i].cnt; j++)
            {
                int sd = find_sock(clients, grps[i].cnt, grps[i].members[j]);
                send(sd, buf, strlen(buf), 0);
            }
        }
    }
}
void handle_addtogroup(int *cli, int n, struct clients *clients, int gid, int s)
{

    int j = 0, l = 1, m = n;
    // for (j = 0; j < n-1; j++)
    //     printf("cli in addto[%d]:%d\n", j + 1, cli[j + 1]);
    char buf[] = "You are added to the group\n";
    j = 0;
    for (; j < grpno; ++j)
    {
        if (grps[j].gid == gid)
        {
            for (int i = grps[j].cnt; i <= 5; i++)
            {
                grps[j].members[i] = cli[l];
                grps[j].cnt++;
                printf("l :%d\n", cli[l]);
                int sd = find_sock(clients, n, cli[l]);
                if (is_admin(cli[l], gid) == 0)
                {
                    send(s, notadmin, strlen(notadmin), 0);
                    return;
                }
                send(sd, buf, strlen(buf), 0);
                l = l + 1;
                m = m - 1;
                printf("m:%d cnt%d\n", m, grps[j].cnt);
                if (m == 0 || grps[j].cnt > 5)
                    break;
            }
        }
    }
}

void handle_removefromgroup(int *cli, int n, struct clients *clients, int gid, int sd)
{
    int cid = find_id(clients, 10, sd);
    if (is_admin(cid, gid) == 0)
    {
        send(sd, notadmin, strlen(notadmin), 0);
    }
    int j = 0, l = 1, m = n;
    // for(j=1;j<n;j++)
    //     printf("cli in addto[%d]:%d\n",j+1,cli[j+1]);
    char buf[256];
    sprintf(buf, "Added removed from group: %d", gid);

    j = 0;
    for (; j < grpno; ++j)
    {
        if (grps[j].gid == gid)
        {
            for (int i = 0; i < grps[j].cnt; i++)
            {
                if (cli[l] == grps[j].members[i])
                {
                    grps[j].members[i] = 0;
                    grps[j].cnt--;
                    int sd = find_sock(clients, n, cli[l]);
                    send(sd, buf, strlen(buf), 0);
                    l++;
                    m--;
                    if (m == 0 || l == n)
                        break;
                }
            }
        }
    }
}

void handle_makeadmin(struct clients *clients, int gid, int cli_id, int n)
{
    char msg[256];
    sprintf(msg, "You are now admin of group: %d", gid);

    int j = 0, k = 1;
    for (; j < grpno; j++)
    {
        if (gid == grps[j].gid)
        {
            for (int i = 0; i < grps[j].cnt; ++i)
            {
                if (cli_id == grps[j].members[i])
                {
                    int sd = find_sock(clients, n, cli_id);

                    grps[j].admin[k++] = cli_id;
                    admincnt++;
                    send(sd, msg, strlen(msg), 0);
                    break;
                }
            }
        }
    }
}
void handle_joingroup(int max_clients, struct clients *client_socket, int sd, int gid, int n)
{
    // printf("maxcli:%d sd:%d gid:%d n:%d k:%d\n", max_clients, sd, gid, n, k);
    char msg[256] = "Added to group";
    grps[grpno].reply++;
    int j = 0;
    while (j < grpno)
    {
        if (grps[j].cnt <= 5)
        {
            if (gid == grps[j].gid)
            {
                for (int i = grps[grpno].cnt; i <= 5; i++)
                {
                    grps[j].members[i] = find_id(client_socket, k, sd);
                    grps[j].cnt++;
                    // sprintf(msg, "Added to group %d", grps[j].gid);
                    send(sd, msg, strlen(msg), 0);
                }
            }
            ++j;
        }
        grpno += 1;
    }
}

void handle_makegroupreq(int num_client, struct clients clients[], int cli_sock, int n, int cli[])
{
    srand(time(0));
    char buffer[256];
    int group = rand() % 999 + 100, i = 0;
    char propmt[256];
    sprintf(propmt, "Do you wnat to be added to group:%d", group);
    // printf("inside %d\n",grpno);
    grps[grpno].gid = group;
    // grps[grpno].cnt++;
    for (int i = 0; i < n; i++)
    {
        int s = find_sock(clients, 10, cli[i]);
        send(s, propmt, strlen(propmt), 0);
    }
    for (i = 0; i < num_client; i++)
    {
        if (cli_sock == clients[i].socket)
        {
            grps[grpno].admin[0] = clients[i].id;
            grps[grpno].members[0] = clients[i].id;
            grps[grpno].cnt += 1;
            break;
        }
    }
    i = 0;

    for (int j = 1; j <= n; j++)
    {
        if (grps[grpno].members[0] != cli[i])
        {
            grps[grpno].members[j] = cli[i];
            grps[grpno].cnt += 1;
            i++;
        }
    }
    for (int i = 0; i < num_client; i++)
    {
        // if(grps[grpno].members[i]!=0){
        // sprintf(buffer, "Added to group %d", group);
        int sock = find_sock(clients, num_client, grps[grpno].members[i]);
        if (sock != 0)
            send(sock, buffer, strlen(buffer), 0);
        if (i == n)
            break;
    }
    // }
    grpno += 1;
}

void handle_makegroup(int num_client, struct clients clients[], int cli_sock, int n, int *cli)
{
    // for (int i = 0; i < n; i++)
    //     printf("cli2:%d\n", cli[i]);
    srand(time(0));
    char buffer[256];
    int group = rand() % 999 + 100, i = 0;
    for (int i = 0; i < n; i++)
    {
        clients[i].group_id = group;
    }
    // printf("inside it2\n");
    grps[grpno].gid = group;
    // grps[grpno].cnt++;
    for (i = 0; i < num_client; i++)
    {
        // if(cli[i]==clients[i].socket)
        if (cli_sock == clients[i].socket)
        {
            grps[grpno].admin[0] = clients[i].id;
            grps[grpno].members[0] = clients[i].id;
            grps[grpno].cnt += 1;
            break;
        }
    }
    i = 0;
    // printf("inside it3\n");
    for (int j = 1; j <= n; j++)
    {
        if (grps[grpno].members[0] != cli[i])
        {
            grps[grpno].members[j] = cli[i];
            grps[grpno].cnt += 1;
            i++;
        }
    }
    // for(int i=0;i<4;i++){
    //     printf("gid:%d cnt:%d admin:%d\n",grps[grpno].gid,grps[grpno].cnt,grps[grpno].admin[0]);
    // }
    // for(int i=0;i<3;i++){
    //     printf("mem:%d\n",grps[grpno].members[i]);
    // }
    // int k = 0;
    for (int i = 0; i < num_client; i++)
    {
        // if(grps[grpno].members[i]!=0){
        sprintf(buffer, "Added to group %d", group);
        int sock = find_sock(clients, num_client, grps[grpno].members[i]);
        if (sock != 0)
            send(sock, buffer, strlen(buffer), 0);
        if (i == n)
            break;
    }
    // }
    grpno += 1;
}

void handle_broadcast(int num_client, struct clients clients[], char *buffer)
{
    char temp[256];
    memcpy(temp, &buffer[11], strlen(buffer));
    for (int i = 0; i < num_client; i++)
    {
        if (clients[i].socket != 0)
        {
            send(clients[i].socket, temp, strlen(temp), 0);
            continue;
        }
    }
}

void handle_client_disconnection(int sd, struct clients *client_socket, int max_clients)
{
    // printf("Client %d disconnected\n",clients[i].id);

    // Remove client socket from the list of clients
    int i = 0;
    for (i = 0; i < max_clients; i++)
    {
        if (client_socket[i].socket == sd)
        {
            // memmove(client_socket + i, client_socket + i + 1, (max_clients - i - 1) * sizeof(struct clients));
            //  char * addr=inet_ntoa(address.sin_addr);
            break;
        }
    }
    max_clients = max_clients - 1;

    // Remove client socket from the master set
    close(sd);
    printf("Client %d disconnected\n", client_socket[i].id);
    client_socket[i].socket = 0;
    client_socket[i].id = -1;
}

void handle_send_command(char *message, int client_socket, struct clients *clients, int num_clients)
{
    // Parse the recipient client ID and message content from the message
    int recipient_id;
    printf("message is:%s\n", message);
    char *content = strtok(message, " ");
    if (content == NULL)
    {
        printf("Invalid /send command format\n");
        return;
    }
    // content[strlen(content)-1]='\0';
    recipient_id = atoi(content);

    content = strtok(NULL, "");
    if (content == NULL)
    {
        printf("Invalid /send command format\n");
        return;
    }
    // printf("recepient:%d\n",recipient_id);

    // printf("content:%d\n",content);
    //  Find the recipient client socket
    int recipient_socket = -1;
    for (int i = 0; i < num_clients; i++)
    {
        if (clients[i].id == recipient_id)
        {
            recipient_socket = clients[i].socket;
            break;
        }
    }

    // Send the message to the recipient client socket
    if (recipient_socket != -1)
    {
        dprintf(recipient_socket, "%d: %s", client_socket, content);
    }
    else
    {
        printf("Invalid recipient ID %d\n", recipient_id);
    }
}

void membersHelper2(char *buf, int gid, int sd)
{
    int i = 0, j = 0;
    for (; i < grpno; i++)
    {
        if (gid == grps[i].gid)
        {
            grps[i].gid = -1;
            for (; j < grps[i].cnt; ++j)
            {
                grps[i].members[j] = 0;
                // sprintf(buf,"Members are :%d\n",grps[i].members[j]);
                send(sd, buf, strlen(buf), 0);
            }
        }
    }
}

void membersHelper(char *buf, int gid, int sd)
{
    int i = 0, j = 0;
    for (; i < grpno; i++)
    {
        if (gid == grps[i].gid)
        {
            for (; j < grps[i].cnt; ++j)
            {
                sprintf(buf, "Members are :%d\n", grps[i].members[j]);
                send(sd, buf, strlen(buf), 0);
            }
        }
    }
}

void adminsHelper2(int gid, int sd)
{
    int i = 0, j = 0;
    for (; i < grpno; i++)
    {
        if (gid == grps[i].gid)
        {
            for (; j < admincnt; ++j)
            {
                grps[i].admin[j] = -1;
            }
        }
    }
}

void adminsHelper(char *buf, int gid, int sd)
{
    int i = 0, j = 0;
    for (; i < grpno; i++)
    {
        if (gid == grps[i].gid)
        {
            for (; j < admincnt; ++j)
            {
                sprintf(buf, "Admins are :%d\n", grps[i].admin[j]);
                send(sd, buf, strlen(buf), 0);
            }
        }
    }
}

void adminsHelper3(char *buf, int gid, int sd, int cid)
{
    int i = 0, j = 0;
    for (; i < grpno; i++)
    {
        if (gid == grps[i].gid)
        {
            for (; j < admincnt; ++j)
            {
                if (grps[i].admin[j] == cid)
                    grps[i].admin[j] = -1;
                // sprintf(buf,"Admins are :%d\n",grps[i].admin[j]);
                send(sd, buf, strlen(buf), 0);
            }
        }
    }
}

void membersHelper3(char *buf, int gid, int sd, int cid)
{
    int i = 0, j = 0;
    for (; i < grpno; i++)
    {
        if (gid == grps[i].gid)
        {
            for (; j < grps[i].cnt; ++j)
            {
                if (grps[i].members[j] == cid)
                    grps[i].admin[j] = 0;
                // sprintf(buf,"Admins are :%d\n",grps[i].admin[j]);
                send(sd, buf, strlen(buf), 0);
            }
        }
    }
}

void handle_active_command(struct clients *clients, int num_clients, int client_socket)
{
    char buffer[1000];
    memset(buffer, '\0', 1000);
    buffer[0] = '\0';
    char id_str[16];
    memset(id_str, '\0', strlen(id_str)); // Construct a list of all connected client IDs
    for (int i = 0; i < num_clients; i++)
    {
        int id = 0;
        id = clients[i].id;
        // id_str[16];
        snprintf(id_str, sizeof(id_str), "%d", id);
        strcat(buffer, id_str);
        strcat(buffer, " ");
    }

    // Send the list of client IDs to the requesting client
    if (buffer[0] != '\0')
    {
        dprintf(client_socket, "Online clients: %s\n", buffer);
    }
    else
    {
        dprintf(client_socket, "No clients currently online\n");
    }
}

void handle_activegroups(struct clients *clients, int sd)
{
    // printf("in activegrps\n");
    int gid, gid_arr[120], k = 0;
    char buf[1024], admin[256], members[256];
    int cid = find_id(clients, 10, sd);
    int i = 0;
    for (; i < grpno; i++)
    {
        for (int j = 0; j < grps[i].cnt; j++)
        {
            // printf("inside j loop\n");
            if (cid == grps[i].members[j])
            {
                gid = grps[i].gid;
                sprintf(buf, "Group_id:%d\n", gid);
                send(sd, buf, strlen(buf), 0);
                bzero(buf, 1024);
                membersHelper(buf, gid, sd);
                adminsHelper(buf, gid, sd);
            }
        }
    }
}
void handle_quit(struct clients *clients, int sd)
{
    int cid = find_id(clients, 10, sd);
    for (int i = 0; i < grpno; i++)
    {

        for (int j = 0; grps[i].cnt; j++)
        {
            if (cid == grps[i].members[j])
            {
                int gid = grps[i].gid;
                if (admincnt == 1 && is_admin(cid, gid) == 1)
                {
                    grps[i].cnt = 0;
                    admincnt = 0;
                    membersHelper2("Grp deleted due to no admin\n", gid, sd);
                    adminsHelper2(gid, sd);
                }
                else
                {
                    int cd = find_id(clients, 10, sd);
                    admincnt -= 1;
                    grps[i].cnt--;
                    membersHelper3("Group exited\n", gid, sd, cd);
                    adminsHelper3("You are no longer admin\n", gid, sd, cd);
                }
            }
        }
    }
    close(sd);
}
int main(int argc, char *argv[])
{
    srand(time(0));
    // group_initializer();
    struct clients client_socket[MAX_CLIENTS];
    int server_socket, max_clients = MAX_CLIENTS, activity, i, valread, sd;
    int max_sd, new_socket, addrlen, client_count = 0;
    struct sockaddr_in address;
    char buffer[BUFFER_SIZE];
    fd_set readfds;
    char *message = "Welcome to the chat room\n";
    int opt = 1;

    // Create server socket
    if ((server_socket = socket(AF_INET, SOCK_STREAM, 0)) == 0)
    {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    // Set socket options
    if (setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0)
    {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }

    // Bind socket to localhost:8080
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(portno);

    if (bind(server_socket, (struct sockaddr *)&address, sizeof(address)) < 0)
    {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }

    // Listen for connections
    if (listen(server_socket, MAX_CLIENTS) < 0)
    {
        perror("listen");
        exit(EXIT_FAILURE);
    }

    // Initialize client sockets
    for (i = 0; i < max_clients; i++)
    {
        client_socket[i].socket = 0;
        client_socket[i].id = -1;
    }

    while (1)
    {
        // Clear the file descriptor set
        FD_ZERO(&readfds);

        // Add server socket to the set
        FD_SET(server_socket, &readfds);
        max_sd = server_socket;

        // Add client sockets to the set
        for (i = 0; i < max_clients; i++)
        {
            sd = client_socket[i].socket;

            // If valid socket descriptor then add to read list
            if (sd > 0)
            {
                FD_SET(sd, &readfds);
            }

            // Highest file descriptor number, need it for the select function
            if (sd > max_sd)
            {
                max_sd = sd;
            }
        }

        // Wait for an activity on one of the sockets
        activity = select(max_sd + 1, &readfds, NULL, NULL, NULL);

        if ((activity < 0) && (errno != EINTR))
        {
            printf("select error");
        }

        // If something happened on the server socket, then it's an incoming connection
        if (FD_ISSET(server_socket, &readfds))
        {
            if ((new_socket = accept(server_socket, (struct sockaddr *)&address, (socklen_t *)&addrlen)) < 0)
            {
                perror("accept");
                exit(EXIT_FAILURE);
            }
            char cli_buf[256];
            // Send welcome message to the client
            send(new_socket, message, strlen(message), 0);

            // Add new socket to array of sockets
            for (i = 0; i < max_clients; i++)
            {
                if (client_socket[i].socket == 0)
                {
                    client_socket[i].socket = new_socket;
                    client_socket[i].id = rand() % 99999;
                    printf("New client connected with socket id %d\n", client_socket[i].id);
                    sprintf(cli_buf, "New client connected with socket id %d\n", client_socket[i].id);
                    send(client_socket[i].socket, cli_buf, strlen(cli_buf), 0);

                    break;
                }
            }
        }

        // Else it's some IO
        for (i = 0; i < max_clients; i++)
        {
            sd = client_socket[i].socket;

            // If the client is active and there is incoming data
            if (FD_ISSET(sd, &readfds))
            {
                // Read the incoming message
                // printf("recved\n");
                char MESSAGE[256] = "\0";
                int num_bytes = recv(sd, MESSAGE, sizeof(MESSAGE), 0);
                // printf("%dhbjjhj %s\n",num_bytes,MESSAGE);
                if (num_bytes == -1)
                {
                    perror("recv");
                    exit(EXIT_FAILURE);
                }
                // else if (num_bytes == 0)
                // {
                //     // Handle client disconnection
                //     handle_client_disconnection(sd, client_socket, &readfds, &max_clients);
                // }
                else
                {
                    // Handle client message
                    buffer[num_bytes] = '\0';
                    if (strncmp(MESSAGE, "/activegroups", 13) == 0)
                    {
                        handle_activegroups(client_socket, sd);
                    }
                    else if (strncmp(MESSAGE, "/sendgroup", 10) == 0)
                    {
                        // printf("in sendgrp\n");
                        char reqstr[256], temp2[256], buf[256];
                        // strcpy(reqstr,MESSAGE);
                        memcpy(reqstr, &MESSAGE[10], strlen(MESSAGE));
                        // printf("reqstr%s:\n", reqstr);
                        strcpy(temp2, reqstr);
                        memcpy(buf, &reqstr[4], strlen(reqstr));
                        // printf("buf is:%s\n", buf);
                        int n = numToks(reqstr);
                        k = n;
                        int i = 0;
                        char *p, temp[11][11];
                        int j = 0;
                        p = strtok(temp2, " ");
                        while (p != NULL)
                        {
                            strcpy(temp[j], p);
                            // printf("temp[%d]is:%d\n", j + 1, atoi(temp[j]));
                            j++;
                            p = strtok(NULL, " ");
                        }
                        int gid = atoi(temp[0]);

                        handle_sendgroup(gid, buf, client_socket, sd);
                        bzero(buffer, strlen(buffer));
                    }
                    else if (strncmp(MESSAGE, "/send", 5) == 0)
                    {
                        handle_send_command(MESSAGE + 5, sd, client_socket, max_clients);
                    }
                    else if (strncmp(MESSAGE, "/active", 7) == 0)
                    {
                        handle_active_command(client_socket, max_clients, sd);
                        bzero(buffer, strlen(buffer));
                    }
                    else if (strncmp(MESSAGE, "/broadcast", 10) == 0)
                    {
                        handle_broadcast(max_clients, client_socket, MESSAGE);
                        bzero(buffer, strlen(buffer));
                    }
                    else if (strncmp(MESSAGE, "/quit", 5) == 0)
                    {
                        getpeername(sd, (struct sockaddr *)&address, (socklen_t *)&addrlen);
                        handle_client_disconnection(sd, client_socket, MAX_CLIENTS);
                        // handle_quit(client_socket,sd);
                        bzero(buffer, strlen(buffer));
                        // printf("hello:\n");
                        //  for(int j=0;j<10;++j){
                        //      printf("cli_sock:%d id:%d\n",client_socket[j].socket,client_socket[j].id);
                        //  }
                        //  int i;
                        //  // Remove client socket from the list of clients
                        //  for ( i = 0; i < max_clients; i++)
                        //  {
                        //      if (client_socket[i].socket == sd)
                        //      {
                        //          //memmove(client_socket + i, client_socket + i + 1, (max_clients - i - 1) * sizeof(struct clients));
                        //          // char * addr=inet_ntoa(address.sin_addr);
                        //          break;
                        //      }
                        //  }
                        //  max_clients=max_clients-1;

                        // // Remove client socket from the master set
                        // close(sd);
                        // printf("Client %d disconnected\n", client_socket[i].id);
                        // client_socket[i].socket=0;
                        // client_socket[i].id=-1;
                    }

                    else if (strncmp(MESSAGE, "/makegroupbroadcast", 19) == 0)
                    {
                        // printf("in broadcastgrp\n");
                        char reqstr[256], temp2[256];
                        // strcpy(reqstr,MESSAGE);
                        memcpy(reqstr, &MESSAGE[19], strlen(MESSAGE));
                        // printf("reqstr: %s:\n", reqstr);
                        strcpy(temp2, reqstr);
                        int n = numToks(reqstr);
                        int i = 0;
                        char *p, temp[11][11];
                        int j = 0;
                        p = strtok(temp2, " ");
                        while (p != NULL)
                        {
                            strcpy(temp[j], p);
                            // printf("temp[%d]is:%d\n", j + 1, atoi(temp[j]));
                            j++;
                            p = strtok(NULL, " ");
                        }

                        i = 0;
                        int gid = atoi(temp[0]);
                        // int cli_id = atoi(temp[1]);
                        // printf("gid:%d  cli_id:%d\n", gid, cli_id);
                        handle_makegroupbroadcast(gid, sd, client_socket);
                    }

                    else if (strncmp(MESSAGE, "/makegroupreq", 13) == 0)
                    {
                        // printf("in makegrpreq\n");
                        char reqstr[256], temp2[256];

                        // strcpy(reqstr,MESSAGE);
                        memcpy(reqstr, &MESSAGE[13], strlen(MESSAGE));
                        // printf("reqstr%s:\n", reqstr);
                        strcpy(temp2, reqstr);
                        int n = numToks(reqstr);
                        int sockd[n];
                        k = n;
                        int i = 0;
                        // printf("in makegrp%d\n",n);
                        char *p, temp[11][11];
                        char *id_arr[n];
                        // p = strtok(temp2, " ");
                        int j = 0;
                        p = strtok(temp2, " ");
                        while (p != NULL)
                        {
                            strcpy(temp[j], p);
                            // printf("temp[%d]is:%d\n", j + 1, atoi(temp[j]));
                            j++;
                            p = strtok(NULL, " ");
                        }

                        i = 0;
                        int id_ar[n];
                        while (i < n)
                        {
                            id_ar[i] = atoi(temp[i]);
                            // printf("id_ar:%d \n", id_ar[i]);

                            i++;
                        }
                        // for(i=0;i<n;i++){
                        //     sockd[i] = find_id(client_socket, n, id_ar[i]);
                        //     printf("socketd:%d\n",sockd[i]);
                        // }
                        // printf("maxcli:%d sd:%d n:%d\n", max_clients, sd, n);
                        handle_makegroupreq(max_clients, client_socket, sd, n, id_ar);
                        bzero(buffer, strlen(buffer));
                    }
                    else if (strncmp(MESSAGE, "/makegroup", 10) == 0)
                    {
                        // printf("in makegrp\n");
                        char reqstr[256], temp2[256];
                        // strcpy(reqstr,MESSAGE);
                        memcpy(reqstr, &MESSAGE[10], strlen(MESSAGE));
                        // printf("reqstr%s:\n", reqstr);
                        strcpy(temp2, reqstr);
                        int n = numToks(reqstr);
                        k = n;
                        int i = 0;
                        char *p, temp[11][11];
                        int j = 0;
                        p = strtok(temp2, " ");
                        while (p != NULL)
                        {
                            strcpy(temp[j], p);
                            // printf("temp[%d]is:%d\n", j + 1, atoi(temp[j]));
                            j++;
                            p = strtok(NULL, " ");
                        }

                        i = 0;
                        int id_ar[n];
                        while (i < n)
                        {
                            id_ar[i] = atoi(temp[i]);
                            // printf("id_ar:%d \n", id_ar[i]);
                            i++;
                        }
                        // printf("maxcli:%d sd:%d n:%d\n", max_clients, sd, n);
                        handle_makegroup(max_clients, client_socket, sd, n, id_ar);
                        bzero(buffer, strlen(buffer));
                    }
                    else if (strncmp("/joingroup", MESSAGE, 10) == 0)
                    {
                        char reqstr[256], temp2[256];
                        int n = numToks(reqstr);
                        int i = 0;
                        // printf("in joingrp%d\n", n);
                        char *p, temp[11][11];
                        // char *id_arr[n];
                        // p = strtok(temp2, " ");
                        int j = 0;
                        p = strtok(temp2, " ");
                        while (p != NULL)
                        {
                            strcpy(temp[j], p);
                            // printf("temp[%d]is:%d\n", j + 1, atoi(temp[j]));
                            j++;
                            p = strtok(NULL, " ");
                        }

                        i = 0;

                        // printf("sd:%d\n", sd);
                        handle_joingroup(max_clients, client_socket, sd, atoi(temp[1]), k);
                    }
                    // else if (strncmp(MESSAGE, "/makeadmin", 10) == 0)
                    // {
                    //     printf("in admin\n");
                    //     char reqstr[256], temp2[256];
                    //     // strcpy(reqstr,MESSAGE);
                    //     memcpy(reqstr, &MESSAGE[10], strlen(MESSAGE));
                    //     printf("reqstr%s:\n", reqstr);
                    //     strcpy(temp2, reqstr);
                    //     int n = numToks(reqstr);
                    //     int i = 0;
                    //     char *p, temp[11][11];
                    //     int j = 0;
                    //     p = strtok(temp2, " ");
                    //     while (p != NULL)
                    //     {
                    //         strcpy(temp[j], p);
                    //         printf("temp[%d]is:%d\n", j + 1, atoi(temp[j]));
                    //         j++;
                    //         p = strtok(NULL, " ");
                    //     }

                    //     i = 0;
                    //     int gid = atoi(temp[0]);
                    //     int cli_id = atoi(temp[1]);
                    //     printf("gid:%d  cli_id:%d\n", gid, cli_id);
                    //     handle_makeadmin(client_socket, gid, cli_id, 10);
                    // }
                    else if (strncmp(MESSAGE, "/addtogroup", 11) == 0)
                    {
                        // printf("in addtogroup\n");
                        char reqstr[256], temp2[256];
                        // strcpy(reqstr,MESSAGE);
                        memcpy(reqstr, &MESSAGE[11], strlen(MESSAGE));
                        // printf("reqstr%s:\n", reqstr);
                        strcpy(temp2, reqstr);
                        int n = numToks(reqstr);
                        int i = 0;
                        char *p, temp[11][11];
                        int j = 0;
                        p = strtok(temp2, " ");
                        while (p != NULL)
                        {
                            strcpy(temp[j], p);
                            // printf("temp[%d]is:%d\n", j + 1, atoi(temp[j]));
                            j++;
                            p = strtok(NULL, " ");
                        }
                        int gid = atoi(temp[0]);
                        // printf("gid:%d\n", gid);
                        i = 1;
                        int id_ar[n];
                        while (i < n)
                        {
                            id_ar[i] = atoi(temp[i]);
                            // printf("id_ar:%d \n", id_ar[i]);
                            i++;
                        }
                        // for(int i=1;i<n;i++)

                        int z = sizeof(id_ar) / sizeof(id_ar[0]);
                        // printf("z:%d\n", z);
                        handle_addtogroup(id_ar, z, client_socket, gid, sd);
                    }
                    else if (strncmp(MESSAGE, "/makeadmin", 10) == 0)
                    {
                        // printf("in admin\n");
                        char reqstr[256], temp2[256];
                        // strcpy(reqstr,MESSAGE);
                        memcpy(reqstr, &MESSAGE[10], strlen(MESSAGE));
                        // printf("reqstr%s:\n", reqstr);
                        strcpy(temp2, reqstr);
                        int n = numToks(reqstr);
                        int i = 0;
                        char *p, temp[11][11];
                        int j = 0;
                        p = strtok(temp2, " ");
                        while (p != NULL)
                        {
                            strcpy(temp[j], p);
                            // printf("temp[%d]is:%d\n", j + 1, atoi(temp[j]));
                            j++;
                            p = strtok(NULL, " ");
                        }

                        i = 0;
                        int gid = atoi(temp[0]);
                        int cli_id = atoi(temp[1]);
                        // printf("gid:%d  cli_id:%d\n", gid, cli_id);
                        handle_makeadmin(client_socket, gid, cli_id, 10);
                    }
                    else if (strncmp(MESSAGE, "/removefromgroup", 16) == 0)
                    {
                        // printf("in removegroup\n");
                        char reqstr[256], temp2[256];
                        // strcpy(reqstr,MESSAGE);
                        memcpy(reqstr, &MESSAGE[16], strlen(MESSAGE));
                        // printf("reqstr%s:\n", reqstr);
                        strcpy(temp2, reqstr);
                        int n = numToks(reqstr);
                        int i = 0;
                        char *p, temp[11][11];
                        int j = 0;
                        p = strtok(temp2, " ");
                        while (p != NULL)
                        {
                            strcpy(temp[j], p);
                            // printf("temp[%d]is:%d\n", j + 1, atoi(temp[j]));
                            j++;
                            p = strtok(NULL, " ");
                        }
                        int gid = atoi(temp[0]);
                        // printf("gid:%d\n", gid);
                        i = 1;
                        int id_ar[n];
                        while (i < n)
                        {
                            id_ar[i] = atoi(temp[i]);
                            // printf("id_ar:%d \n", id_ar[i]);
                            i++;
                        }
                        // for(int i=1;i<n;i++)

                        int z = sizeof(id_ar) / sizeof(id_ar[0]);
                        // printf("z:%d\n", z);
                        handle_removefromgroup(id_ar, z, client_socket, gid, sd);
                    }
                    else
                    {
                        printf("Invalid command from client %d: %s", client_socket, buffer);
                    }
                }
            }
        }
    }
    return 0;
}
